package com.xy.www.xylib.listener;

/**
 * @author liuml
 * @explain
 * @time 2019/1/9 11:45
 */
public interface OnHandleListener {
    void onBegin();

    void onEnd(int result);
}